<?php
/**
 * Customer Payment Instructions Email Template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/customer-payment-instructions.php
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates/Emails
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

$order = $email->object;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html($email->get_subject()); ?></title>
    <style type="text/css">
        /* Reset styles */
        body, table, td, p, a, li, blockquote {
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }
        table, td {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }
        img {
            -ms-interpolation-mode: bicubic;
        }

        /* Main styles */
        body {
            margin: 0;
            padding: 0;
            background-color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #374151;
        }

        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .email-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #ffffff;
            padding: 40px 30px;
            text-align: center;
        }

        .email-header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            letter-spacing: -0.025em;
        }

        .email-content {
            padding: 40px 30px;
        }

        .payment-card {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border: 2px solid #0ea5e9;
            border-radius: 16px;
            padding: 30px;
            margin: 30px 0;
            text-align: center;
        }

        .payment-title {
            font-size: 18px;
            font-weight: 600;
            color: #0c4a6e;
            margin-bottom: 20px;
        }

        .recipient-email {
            font-size: 24px;
            font-weight: 700;
            color: #0369a1;
            margin: 15px 0;
            word-break: break-all;
        }

        .amount-display {
            font-size: 48px;
            font-weight: 800;
            color: #059669;
            margin: 25px 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .reference-code {
            background-color: #f1f5f9;
            border: 2px dashed #64748b;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            font-family: 'Courier New', Monaco, Consolas, 'Liberation Mono', monospace;
            font-size: 16px;
            font-weight: 600;
            color: #475569;
            letter-spacing: 1px;
        }

        .qr-code-container {
            margin: 30px 0;
            padding: 20px;
            background-color: #ffffff;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            display: inline-block;
        }

        .qr-code-placeholder {
            width: 200px;
            height: 200px;
            background-color: #f8fafc;
            border: 2px dashed #cbd5e1;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            color: #64748b;
            margin: 0 auto;
        }

        .instruction-list {
            background-color: #fefefe;
            border-left: 4px solid #3b82f6;
            border-radius: 0 8px 8px 0;
            padding: 25px;
            margin: 30px 0;
        }

        .instruction-list h3 {
            color: #1e40af;
            font-size: 18px;
            margin-top: 0;
            margin-bottom: 15px;
        }

        .instruction-list ol {
            margin: 0;
            padding-left: 20px;
        }

        .instruction-list li {
            margin-bottom: 8px;
            color: #374151;
        }

        .warning-box {
            background-color: #fef3c7;
            border: 1px solid #f59e0b;
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
        }

        .warning-box .warning-icon {
            color: #d97706;
            font-size: 20px;
            margin-right: 8px;
        }

        .warning-text {
            color: #92400e;
            font-weight: 500;
        }

        .email-footer {
            background-color: #f8fafc;
            padding: 30px;
            text-align: center;
            border-top: 1px solid #e2e8f0;
        }

        .email-footer p {
            margin: 5px 0;
            color: #6b7280;
            font-size: 14px;
        }

        .contact-info {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        /* Mobile responsive */
        @media only screen and (max-width: 600px) {
            .email-container {
                width: 100% !important;
                margin: 0 !important;
            }

            .email-header,
            .email-content,
            .email-footer {
                padding: 20px !important;
            }

            .amount-display {
                font-size: 36px !important;
            }

            .recipient-email {
                font-size: 18px !important;
            }

            .qr-code-placeholder {
                width: 150px !important;
                height: 150px !important;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <!-- Header -->
        <div class="email-header">
            <h1>💸 Payment Instructions</h1>
        </div>

        <!-- Main Content -->
        <div class="email-content">
            <p>Hello <?php echo esc_html($order->get_billing_first_name()); ?>,</p>

            <p>Thank you for your order! To complete your payment, please send an e-transfer with the following details:</p>

            <!-- Payment Details Card -->
            <div class="payment-card">
                <div class="payment-title">Send e-Transfer to:</div>

                <div class="recipient-email">
                    <?php echo esc_html(get_option('etransfer_recipient_email', 'payments@example.com')); ?>
                </div>

                <div class="amount-display">
                    <?php echo wp_kses_post($order->get_formatted_order_total()); ?>
                </div>

                <div style="margin: 20px 0;">
                    <strong>Reference/Message:</strong>
                    <div class="reference-code">
                        Order #<?php echo esc_html($order->get_order_number()); ?>
                    </div>
                </div>

                <!-- QR Code Placeholder -->
                <div class="qr-code-container">
                    <div class="qr-code-placeholder">
                        <?php
                        // Hook for QR code - plugins can replace this
                        do_action('etransfer_email_qr_code', $order);
                        ?>
                        QR Code will appear here
                    </div>
                </div>
            </div>

            <!-- Instructions -->
            <div class="instruction-list">
                <h3>📋 How to send the e-Transfer:</h3>
                <ol>
                    <li>Log into your online banking or mobile app</li>
                    <li>Navigate to "Send Money" or "Interac e-Transfer"</li>
                    <li>Enter the recipient email: <strong><?php echo esc_html(get_option('etransfer_recipient_email', 'payments@example.com')); ?></strong></li>
                    <li>Enter the amount: <strong><?php echo wp_kses_post($order->get_formatted_order_total()); ?></strong></li>
                    <li>In the message field, include: <strong>Order #<?php echo esc_html($order->get_order_number()); ?></strong></li>
                    <li>Send the transfer (no security question needed)</li>
                </ol>
            </div>

            <!-- Warning Box -->
            <div class="warning-box">
                <span class="warning-icon">⚠️</span>
                <span class="warning-text">
                    <strong>Important:</strong> Please include the order number in your e-Transfer message to ensure quick processing of your order.
                </span>
            </div>

            <!-- Order Details -->
            <div style="margin-top: 40px;">
                <h3 style="color: #374151; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Order Details</h3>

                <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                    <tr style="background-color: #f9fafb;">
                        <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600;">Order Number:</td>
                        <td style="padding: 12px; border: 1px solid #e5e7eb;">#<?php echo esc_html($order->get_order_number()); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600;">Order Date:</td>
                        <td style="padding: 12px; border: 1px solid #e5e7eb;"><?php echo esc_html($order->get_date_created()->date_i18n(get_option('date_format'))); ?></td>
                    </tr>
                    <tr style="background-color: #f9fafb;">
                        <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600;">Total Amount:</td>
                        <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #059669;"><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                    </tr>
                </table>
            </div>

            <p style="margin-top: 30px;">Once we receive your e-Transfer, we'll process your order immediately and send you a confirmation email.</p>

            <p>If you have any questions, please don't hesitate to contact us.</p>

            <p>Thank you for your business!</p>
        </div>

        <!-- Footer -->
        <div class="email-footer">
            <p><strong><?php echo esc_html(get_bloginfo('name')); ?></strong></p>
            <p><?php echo esc_html(get_option('woocommerce_email_footer_text')); ?></p>

            <div class="contact-info">
                <p>Questions? Contact us at <?php echo esc_html(get_option('admin_email')); ?></p>
                <p>This is an automated message, please do not reply to this email.</p>
            </div>
        </div>
    </div>
</body>
</html>