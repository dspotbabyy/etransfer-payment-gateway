import React from 'react';
import { Box } from '@mui/material';

// Tab components
import Dashboard from './Dashboard';
import OrderDashboard from './OrderDashboard';
import AccountList from './AccountList';
import UserInfo from './UserInfo';

const TabNavigation = ({ user, activeTab = 0 }) => {
  // Get user role from localStorage if not passed as prop
  const currentUser = user || JSON.parse(localStorage.getItem('user') || '{}');
  const isCustomer = currentUser.role === 'customer';

  // Define tabs based on user role
  const tabs = isCustomer ? [
    {
      label: 'Dashboard',
      component: <Dashboard />
    },
    {
      label: 'Orders',
      component: <OrderDashboard />
    },
    {
      label: 'User Info',
      component: <UserInfo />
    }
  ] : [
    {
      label: 'Dashboard',
      component: <Dashboard />
    },
    {
      label: 'Orders',
      component: <OrderDashboard />
    },
    {
      label: 'Accounts',
      component: <AccountList />
    },
    {
      label: 'User Info',
      component: <UserInfo />
    }
  ];

  return (
    <Box sx={{ width: '100%', height: '100%' }}>
      {tabs[activeTab]?.component || tabs[0].component}
    </Box>
  );
};

export default TabNavigation; 