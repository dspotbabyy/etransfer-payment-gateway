const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Database configuration based on environment
const isProduction = process.env.NODE_ENV === 'production' || process.env.RENDER === 'true';
const DATABASE_URL = process.env.DATABASE_URL;

console.log('🔧 Database Configuration:');
console.log('NODE_ENV:', process.env.NODE_ENV);
console.log('RENDER:', process.env.RENDER);
console.log('DATABASE_URL exists:', !!DATABASE_URL);
console.log('isProduction:', isProduction);

let db;

if (isProduction && DATABASE_URL) {
  // PostgreSQL for production (Render.com)
  console.log('🐘 Using PostgreSQL database for production');
  const { Pool } = require('pg');
  const pool = new Pool({
    connectionString: DATABASE_URL,
    ssl: {
      rejectUnauthorized: false
    }
  });
  
  // Test connection
  pool.connect((err, client, release) => {
    if (err) {
      console.error('❌ Error connecting to PostgreSQL:', err);
    } else {
      console.log('✅ Successfully connected to PostgreSQL');
      release();
    }
  });
  
  db = {
    run: (sql, params, callback) => {
      const query = sql.replace(/\?/g, (match, offset) => {
        const index = sql.substring(0, offset).split('?').length;
        return `$${index}`;
      });
      
      if (callback) {
        pool.query(query, params || [])
          .then(result => {
            // For INSERT statements, simulate lastID
            if (sql.toLowerCase().includes('insert') && result.rows && result.rows[0]) {
              callback.call({ lastID: result.rows[0].id }, null);
            } else {
              callback(null, result);
            }
          })
          .catch(err => callback(err));
      } else {
        return pool.query(query, params || []);
      }
    },
    get: (sql, params, callback) => {
      const query = sql.replace(/\?/g, (match, offset) => {
        const index = sql.substring(0, offset).split('?').length;
        return `$${index}`;
      });
      
      pool.query(query, params || [])
        .then(result => callback(null, result.rows[0]))
        .catch(err => callback(err));
    },
    all: (sql, params, callback) => {
      const query = sql.replace(/\?/g, (match, offset) => {
        const index = sql.substring(0, offset).split('?').length;
        return `$${index}`;
      });
      
      pool.query(query, params || [])
        .then(result => callback(null, result.rows))
        .catch(err => callback(err));
    }
  };
} else {
  // SQLite for development
  console.log('🗄️  Using SQLite database for development');
  const dbPath = path.join(__dirname, 'orders.db');
  db = new sqlite3.Database(dbPath);
}

// Initialize database tables
const initDatabase = () => {
  return new Promise((resolve, reject) => {
    if (isProduction && DATABASE_URL) {
      // PostgreSQL schema
      console.log('🐘 Creating PostgreSQL tables...');
      
      const createBankAccountsTable = `
        CREATE TABLE IF NOT EXISTS bank_accounts (
          id SERIAL PRIMARY KEY,
          email TEXT UNIQUE NOT NULL,
          username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          first_name TEXT,
          last_name TEXT,
          url_site TEXT,
          role TEXT NOT NULL CHECK (role IN ('admin', 'customer')),
          create_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `;
      
      const createOrdersTable = `
        CREATE TABLE IF NOT EXISTS orders (
          id SERIAL PRIMARY KEY,
          woo_order_id TEXT,
          status TEXT NOT NULL DEFAULT 'pending',
          date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          total DECIMAL NOT NULL,
          customer_name TEXT,
          customer_email TEXT NOT NULL,
          description TEXT,
          ip_address TEXT,
          bank_account_id INTEGER REFERENCES bank_accounts(id)
        )
      `;
      
      db.run(createBankAccountsTable, [], (err) => {
        if (err) {
          console.error('Error creating bank_accounts table:', err);
          reject(err);
        } else {
          console.log('Bank accounts table created successfully');
          
          db.run(createOrdersTable, [], (err) => {
            if (err) {
              console.error('Error creating orders table:', err);
              reject(err);
            } else {
              console.log('Orders table created successfully');
              resolve();
            }
          });
        }
      });
    } else {
      // SQLite schema (existing code)
      db.run(`
        CREATE TABLE IF NOT EXISTS orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          woo_order_id TEXT,
          status TEXT NOT NULL DEFAULT 'pending',
          date DATETIME DEFAULT CURRENT_TIMESTAMP,
          total REAL NOT NULL,
          customer_name TEXT,
          customer_email TEXT NOT NULL,
          description TEXT,
          ip_address TEXT,
          bank_account_id INTEGER,
          FOREIGN KEY (bank_account_id) REFERENCES bank_accounts (id)
        )
      `, (err) => {
        if (err) {
          console.error('Error creating orders table:', err);
          reject(err);
        } else {
          console.log('Orders table created successfully with new structure');
          
          db.run(`
            CREATE TABLE IF NOT EXISTS bank_accounts (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              email TEXT UNIQUE NOT NULL,
              username TEXT UNIQUE NOT NULL,
              password TEXT NOT NULL,
              first_name TEXT,
              last_name TEXT,
              url_site TEXT,
              role TEXT NOT NULL CHECK (role IN ('admin', 'customer')),
              create_date DATETIME DEFAULT CURRENT_TIMESTAMP
            )
          `, (err) => {
            if (err) {
              console.error('Error creating bank_accounts table:', err);
              reject(err);
            } else {
              console.log('Bank accounts table created successfully');
              
              db.run(`ALTER TABLE bank_accounts ADD COLUMN first_name TEXT`, (err) => {
                if (err && !err.message.includes('duplicate column name')) {
                  console.error('Error adding first_name column:', err);
                }
              });
              
              db.run(`ALTER TABLE bank_accounts ADD COLUMN last_name TEXT`, (err) => {
                if (err && !err.message.includes('duplicate column name')) {
                  console.error('Error adding last_name column:', err);
                } else {
                  console.log('Database schema updated successfully');
                  resolve();
                }
              });
            }
          });
        }
      });
    }
  });
};

module.exports = { db, initDatabase }; 